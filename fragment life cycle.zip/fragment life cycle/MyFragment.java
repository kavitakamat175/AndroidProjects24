package com.example.myapp;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;



public class MyFragment extends Fragment {
private final String FTAG="My Fragment";
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
Log.i(FTAG,"onCreate method called");

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Log.i(FTAG,"onCreateView method called");
        return inflater.inflate(R.layout.fragment_my, container, false);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        Log.i(FTAG,"onAttach method called");
    }

    @Override
    public void onDetach() {
        super.onDetach();
        Log.i(FTAG,"onDetach method called");
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Log.i(FTAG,"onActivityCreated method called");
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.i(FTAG,"onPause method called");
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.i(FTAG,"onResume method called");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.i(FTAG,"onDestroy method called");
   }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        Log.i(FTAG,"onDestroyView method called");
    }

    @Override
    public void onStop() {
        super.onStop();
        Log.i(FTAG,"onStop method called");
    }

    @Override
    public void onStart() {
        super.onStart();
        Log.i(FTAG,"onStart method called");
    }
}