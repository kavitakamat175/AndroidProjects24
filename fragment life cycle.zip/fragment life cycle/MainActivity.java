package com.example.myapp;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
private final String TAG="Main Activity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i(TAG, "MA on create method called");

    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.i(TAG, "MA onRestart method called");

    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i(TAG, "MA onStop method called");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i(TAG, "MA onPause method called");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i(TAG,"MA onResume method called");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i(TAG,"MA onDestroy method called");
    }

    public void call(View view)
    {
        MyFragment myFragment=new MyFragment();
        getSupportFragmentManager().beginTransaction()
                .add(R.id.frame,myFragment,null)
                .commit();
    }
}